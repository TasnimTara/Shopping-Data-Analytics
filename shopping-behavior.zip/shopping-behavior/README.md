# shopping-behavior

Replace all template text `[]` with your own words. Be sure that there is no template text in your `README.md` file before pushing.

[A quick summary of this project]

## Observations 

[A short write-up of the workflow this project followed, your observations on the visualizations, and interpretations of analyses. Include challenges faced and possible next actions]
