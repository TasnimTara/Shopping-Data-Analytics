# Part 2

Validate your `02transform.ipynb` with the screenshots below:

![head](/docs/images/head.png)  
*Final Head*  

![nulls](/docs/images/nulls.png)  
*Final Count of Nulls*  

![shape](/docs/images/shape.png)  
*Final DF Shape*  