# Part 1

Validate your visualizations with the screenshots below:

![age](/docs/images/age.png)

*Age Hist*

![purchamount](/docs/images/purchamount.png)

*Purchase Amount Hist*

![review](/docs/images/rev_rating.png)

*Review Hist*

![prev_purchase](/docs/images/prev_purchase.png)

*Previous Purchases Hist*

![gendident](/docs/images/gendident.png)

*Gender Bar Chart*

![seasons](/docs/images/seasons.png)

*Season Bar Chart*

![shipp](/docs/images/shipp.png)

*Shipping Type Bar Chart*

![promo_code](/docs/images/promo_code.png)

*Promo Code Bar Chart*

![payment](/docs/images/payment.png)

*Payment Bar Chart*

![freq](/docs/images/freq.png)

*Frequency Bar Chart*

![states](/docs/images/states.png)

*States Bar Chart*

![gend_box](/docs/images/gend_box.png)

*Gender Box Plot*

![payment_method](/docs/images/payment_method.png)

*Payment Box Plot*

![season_box](/docs/images/season_box.png)

*Season Box Plot*

![review_rate](/docs/images/review_rate.png)

*Review Rating Box Plot*

![promo_code](/docs/images/promo_code.png)

*Promo Code Box Plot*

![grids](/docs/images/grids.png)

*Grids*