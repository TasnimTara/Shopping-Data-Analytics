# Part 3

Validate your `03analysis.ipynb` with the screenshots below:

![pivot_colors](/docs/images/pivot_color.png)  
*1st Pivot Table*  

![baby_blue](/docs/images/baby_blue.png)  
*Most Popular Colors* 

![purchased](/docs/images/purchased.png)  
*2nd Pivot Table*  

![leggings](/docs/images/leggings.png)  
*Most Popular Item*  

![prev_purchases](/docs/images/prev_purchases.png)  
*Mean of 3 Select Columns*  

![rev_rating_low](/docs/images/rev_rating_low.png)  
*Proportions of Low Purchases* 

![rev_rating_high](/docs/images/rev_rating_high.png)  
*Proportions of High Purchases* 